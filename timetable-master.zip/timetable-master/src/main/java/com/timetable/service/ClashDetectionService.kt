package com.timetable.service

import com.timetable.models.Activity
import com.timetable.models.Module
import com.timetable.models.Term
import org.springframework.stereotype.Service

@Service
class ClashDetectionService {
    fun checkCollisions(term: Term): List<String> {
        val errors: MutableList<String> = ArrayList()
        val modules = term.modules
        println(modules)
        val checkedModules: MutableList<Module> = ArrayList()
        for (currentModule in modules) {
            val checkedActivities: MutableList<Activity> = ArrayList()
            for (activity in currentModule.activities!!) {
                for (moduleToCheck in modules) {
                    if (checkedModules.contains(moduleToCheck)) {
                        continue
                    }
                    val day = activity.day
                    val activityOfTheSameDay = moduleToCheck.activities!!.stream().filter {
                        it.day == day &&
                                it.id != activity.id &&
                                !checkedActivities.contains(it)
                    }.toList()
                    for (compared in activityOfTheSameDay) {
                        if (checkedActivities.contains(compared) ||
                                activity.start!!.isAfter(compared.end) || activity.start == compared.end ||
                                activity.end!!.isBefore(compared.start) || activity.end == compared.start) {
                            continue
                        }
                        errors.add("Clash between activities: ${System.lineSeparator()}" +
                                "$activity ${System.lineSeparator()} in ${System.lineSeparator()}" +
                                "Module(${currentModule.id}, ${currentModule.name} )"+
                                "${System.lineSeparator()}and${System.lineSeparator()}" +
                                "$compared ${System.lineSeparator()}in${System.lineSeparator()}" +
                                "Module(${moduleToCheck.id}, ${moduleToCheck.name} )")
                    }
                }
                checkedActivities.add(activity)
            }
            checkedModules.add(currentModule)
        }
        return errors
    }
}