/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.timetable

import java.sql.*
import java.util.logging.Level
import java.util.logging.Logger

/**
 *
 * @author umard
 */
class db {
    var ps: PreparedStatement? = null
    var st: Statement? = null
    var res: ResultSet? = null
    var sp: Savepoint? = null

    companion object {
        // Dev side
        @JvmStatic
        @get:Throws(SQLException::class)
        val connection: Connection
            get() {
                val con: Connection
                con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/time-table-system",
                    "root",
                    "root1234$"
                ) // Dev side
                con.autoCommit = false
                return con
            }

        init {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver")
            } catch (ex: ClassNotFoundException) {
                Logger.getLogger(db::class.java.name).log(Level.SEVERE, null, ex)
                System.exit(-1)
            }
        }
    }
}