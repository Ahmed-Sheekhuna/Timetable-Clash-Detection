package com.timetable.entity

import jakarta.persistence.*

@Entity(name = "term")
class TermEntity(
        @Column(nullable = false)
        var termNumber: Int? = null,
        @Column(nullable = false)
        var startMonth: Int? = null,
        @Column(nullable = false)
        var endMonth: Int? = null,
        @Column(nullable = true)
        @OneToMany(fetch = FetchType.EAGER, cascade = [CascadeType.MERGE])
        var modules: List<ModuleEntity>? = null,
        @Column(nullable = false)
        var year: Int? = null,
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null)