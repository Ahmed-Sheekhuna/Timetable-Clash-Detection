package com.timetable.entity

import jakarta.persistence.*

@Entity(name = "module")
class ModuleEntity(
        @Column(nullable = false)
        var name: String? = null,
        @Column(nullable = false)
        var required: Boolean? = null,
        @Column(nullable = true)
        @OneToMany(fetch = FetchType.EAGER, cascade = [CascadeType.MERGE])
        var activities: List<ActivityEntity>? = null,
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null)