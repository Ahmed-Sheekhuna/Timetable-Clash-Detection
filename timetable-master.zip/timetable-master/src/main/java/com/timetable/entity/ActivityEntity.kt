package com.timetable.entity

import jakarta.persistence.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

@Entity(name = "activity")
class ActivityEntity(
        @Column(nullable = false)
        var name: String? = null,
        @Column(nullable = false)
        var type: String? = null,
        @Column(nullable = false)
        var start: LocalTime? = null,
        @Column(nullable = false)
        var end: LocalTime? = null,
        @Column(nullable = false)
        var day: DayOfWeek? = null,
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null)
