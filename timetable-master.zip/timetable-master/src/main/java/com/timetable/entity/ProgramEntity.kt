package com.timetable.entity

import jakarta.persistence.*

@Entity(name = "program")
class ProgramEntity(
        @Column(nullable = false)
        var name: String? = null,
        @Column(nullable = false)
        var startYear: Int? = null,
        @Column(nullable = false)
        var type: String? = null,
        @Column(nullable = false)
        @OneToMany(fetch = FetchType.EAGER, cascade = [CascadeType.MERGE])
        var terms: List<TermEntity>? = null,
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null)
