package com.timetable.controller;

import com.timetable.models.Program;
import com.timetable.models.Term;
import com.timetable.service.ClashDetectionService;
import com.timetable.service.ProgramService;
import com.timetable.service.TermService;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.emptyList;

@Component
@FxmlView("programStudy.fxml")
public class ProgramController extends AbstractController {
    @FXML
    private Button cancelButton;
    @FXML
    private ListView<Term> termView;
    @FXML
    private ChoiceBox<String> typeBox;
    @FXML
    private TextField nameField;
    @FXML
    private Spinner<Integer> yearSpinner;
    private final ObservableList<Term> termList = FXCollections.observableArrayList();
    @Autowired
    private TermService termService;
    @Autowired
    private ProgramService programService;
    @Autowired
    private ClashDetectionService clashDetectionService;
    private Program program;

    @FXML
    private void cancel(ActionEvent event) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void checkClashes(ActionEvent event) {
        List<String> errors = clashDetectionService.checkCollisions(termView.getSelectionModel().getSelectedItem());
        if (errors.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Clashes result");
            alert.setHeaderText(null);
            alert.setContentText("Clashes not detected");
            alert.showAndWait();
        } else {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Clashes result");
            errorAlert.setContentText(String.join(System.lineSeparator(), errors));
            errorAlert.showAndWait();
        }
    }

    @FXML
    private void save(ActionEvent event) {
        if (termList.stream().anyMatch(term -> term.getId() == null || term.getId() == 0)) {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("You must configure all terms before saving");
            errorAlert.showAndWait();
            return;
        }
        program.setTerms(new ArrayList<>(termList));
        program.setName(nameField.getText());
        program.setStartYear(yearSpinner.getValue());
        program.setType(typeBox.getValue());
        programService.saveProgram(program);
        cancel(event);
    }

    @FXML
    public void initialize() {
        termList.clear();
        termList.add(new Term(0L, 1, 9, 12, 1, emptyList()));
        termList.add(new Term(0L, 2, 1, 4, 1, emptyList()));
        populateUndergraduateSpecificTerms();
        termView.setItems(termList);
        typeBox.getSelectionModel()
                .selectedItemProperty()
                .addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
                    if ("undergraduate".equals(newValue)) {
                        if (termList.size() < 6) {
                            populateUndergraduateSpecificTerms();
                        }
                    } else {
                        if (termList.size() > 2) {
                            termList.remove(2, 6);
                        }
                    }
                });
        program = new Program();
    }

    private void populateUndergraduateSpecificTerms() {
        termList.add(new Term(0L, 1, 9, 12, 2, emptyList()));
        termList.add(new Term(0L, 2, 1, 4, 2, emptyList()));
        termList.add(new Term(0L, 1, 9, 12, 3, emptyList()));
        termList.add(new Term(0L, 2, 1, 4, 3, emptyList()));
    }

    @FXML
    private void configureTerm(ActionEvent event) {
        Stage stage = createStage(TermController.class, "Configure term", event);
        Term term = termView.getSelectionModel().getSelectedItem();
        applicationContext.getBean(TermController.class).setTerm(term);
        stage.showAndWait();
        if (stage.getUserData() != null) {
            termList.set(termList.indexOf(term), termService.getTerm((Long) stage.getUserData()));
        }
    }

    public void setProgram(Program program){
        this.program = program;
        termList.clear();
        termList.addAll(program.getTerms());
        nameField.setText(program.getName());
        typeBox.setValue(program.getType());
    }
}
