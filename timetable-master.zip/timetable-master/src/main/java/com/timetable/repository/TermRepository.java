package com.timetable.repository;

import com.timetable.entity.TermEntity;
import org.springframework.data.repository.CrudRepository;

public interface TermRepository extends CrudRepository<TermEntity, Long> {
}
