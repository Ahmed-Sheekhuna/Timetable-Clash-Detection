package com.timetable.repository;

import com.timetable.entity.ProgramEntity;
import org.springframework.data.repository.CrudRepository;

public interface ProgramRepository extends CrudRepository<ProgramEntity, Long> {
}
