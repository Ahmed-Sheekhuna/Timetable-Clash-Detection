package com.timetable.repository;

import com.timetable.entity.ModuleEntity;
import org.springframework.data.repository.CrudRepository;

public interface ModuleRepository extends CrudRepository<ModuleEntity, Long> {
}
